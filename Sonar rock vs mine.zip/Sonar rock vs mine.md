# importing libraries


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay, roc_curve, roc_auc_score
```

# Loading the data set


```python
sonar_data = pd.read_csv("C:\\Users\\Sai Akhil\\OneDrive\\Desktop\\ml project\\Copy of sonar data.csv", header=None)
```


```python
sonar_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>51</th>
      <th>52</th>
      <th>53</th>
      <th>54</th>
      <th>55</th>
      <th>56</th>
      <th>57</th>
      <th>58</th>
      <th>59</th>
      <th>60</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0200</td>
      <td>0.0371</td>
      <td>0.0428</td>
      <td>0.0207</td>
      <td>0.0954</td>
      <td>0.0986</td>
      <td>0.1539</td>
      <td>0.1601</td>
      <td>0.3109</td>
      <td>0.2111</td>
      <td>...</td>
      <td>0.0027</td>
      <td>0.0065</td>
      <td>0.0159</td>
      <td>0.0072</td>
      <td>0.0167</td>
      <td>0.0180</td>
      <td>0.0084</td>
      <td>0.0090</td>
      <td>0.0032</td>
      <td>R</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0453</td>
      <td>0.0523</td>
      <td>0.0843</td>
      <td>0.0689</td>
      <td>0.1183</td>
      <td>0.2583</td>
      <td>0.2156</td>
      <td>0.3481</td>
      <td>0.3337</td>
      <td>0.2872</td>
      <td>...</td>
      <td>0.0084</td>
      <td>0.0089</td>
      <td>0.0048</td>
      <td>0.0094</td>
      <td>0.0191</td>
      <td>0.0140</td>
      <td>0.0049</td>
      <td>0.0052</td>
      <td>0.0044</td>
      <td>R</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0262</td>
      <td>0.0582</td>
      <td>0.1099</td>
      <td>0.1083</td>
      <td>0.0974</td>
      <td>0.2280</td>
      <td>0.2431</td>
      <td>0.3771</td>
      <td>0.5598</td>
      <td>0.6194</td>
      <td>...</td>
      <td>0.0232</td>
      <td>0.0166</td>
      <td>0.0095</td>
      <td>0.0180</td>
      <td>0.0244</td>
      <td>0.0316</td>
      <td>0.0164</td>
      <td>0.0095</td>
      <td>0.0078</td>
      <td>R</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0100</td>
      <td>0.0171</td>
      <td>0.0623</td>
      <td>0.0205</td>
      <td>0.0205</td>
      <td>0.0368</td>
      <td>0.1098</td>
      <td>0.1276</td>
      <td>0.0598</td>
      <td>0.1264</td>
      <td>...</td>
      <td>0.0121</td>
      <td>0.0036</td>
      <td>0.0150</td>
      <td>0.0085</td>
      <td>0.0073</td>
      <td>0.0050</td>
      <td>0.0044</td>
      <td>0.0040</td>
      <td>0.0117</td>
      <td>R</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0762</td>
      <td>0.0666</td>
      <td>0.0481</td>
      <td>0.0394</td>
      <td>0.0590</td>
      <td>0.0649</td>
      <td>0.1209</td>
      <td>0.2467</td>
      <td>0.3564</td>
      <td>0.4459</td>
      <td>...</td>
      <td>0.0031</td>
      <td>0.0054</td>
      <td>0.0105</td>
      <td>0.0110</td>
      <td>0.0015</td>
      <td>0.0072</td>
      <td>0.0048</td>
      <td>0.0107</td>
      <td>0.0094</td>
      <td>R</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 61 columns</p>
</div>



# preproceesing of the data


```python
# Encoding the target variable
sonar_data[60] = sonar_data[60].apply(lambda x: 1 if x == 'M' else 0)
```


```python
# Separating features and target
X = sonar_data.drop(columns=60, axis=1)
Y = sonar_data[60]
```


```python
# Splitting the data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.1, stratify=Y, random_state=1)
```


```python
# Standardizing the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
```

# Exploratory Data Analysis (EDA)


```python
# Statistical summary of the data
print(sonar_data.describe())
```

                   0           1           2           3           4           5   \
    count  208.000000  208.000000  208.000000  208.000000  208.000000  208.000000   
    mean     0.029164    0.038437    0.043832    0.053892    0.075202    0.104570   
    std      0.022991    0.032960    0.038428    0.046528    0.055552    0.059105   
    min      0.001500    0.000600    0.001500    0.005800    0.006700    0.010200   
    25%      0.013350    0.016450    0.018950    0.024375    0.038050    0.067025   
    50%      0.022800    0.030800    0.034300    0.044050    0.062500    0.092150   
    75%      0.035550    0.047950    0.057950    0.064500    0.100275    0.134125   
    max      0.137100    0.233900    0.305900    0.426400    0.401000    0.382300   
    
                   6           7           8           9   ...          51  \
    count  208.000000  208.000000  208.000000  208.000000  ...  208.000000   
    mean     0.121747    0.134799    0.178003    0.208259  ...    0.013420   
    std      0.061788    0.085152    0.118387    0.134416  ...    0.009634   
    min      0.003300    0.005500    0.007500    0.011300  ...    0.000800   
    25%      0.080900    0.080425    0.097025    0.111275  ...    0.007275   
    50%      0.106950    0.112100    0.152250    0.182400  ...    0.011400   
    75%      0.154000    0.169600    0.233425    0.268700  ...    0.016725   
    max      0.372900    0.459000    0.682800    0.710600  ...    0.070900   
    
                   52          53          54          55          56          57  \
    count  208.000000  208.000000  208.000000  208.000000  208.000000  208.000000   
    mean     0.010709    0.010941    0.009290    0.008222    0.007820    0.007949   
    std      0.007060    0.007301    0.007088    0.005736    0.005785    0.006470   
    min      0.000500    0.001000    0.000600    0.000400    0.000300    0.000300   
    25%      0.005075    0.005375    0.004150    0.004400    0.003700    0.003600   
    50%      0.009550    0.009300    0.007500    0.006850    0.005950    0.005800   
    75%      0.014900    0.014500    0.012100    0.010575    0.010425    0.010350   
    max      0.039000    0.035200    0.044700    0.039400    0.035500    0.044000   
    
                   58          59          60  
    count  208.000000  208.000000  208.000000  
    mean     0.007941    0.006507    0.533654  
    std      0.006181    0.005031    0.500070  
    min      0.000100    0.000600    0.000000  
    25%      0.003675    0.003100    0.000000  
    50%      0.006400    0.005300    1.000000  
    75%      0.010325    0.008525    1.000000  
    max      0.036400    0.043900    1.000000  
    
    [8 rows x 61 columns]
    


```python
# Distribution of the target variable
plt.figure(figsize=(6, 4))
sns.countplot(x=sonar_data[60])
plt.title('Distribution of Rocks and Mines')
plt.show()
```


    
![png](output_12_0.png)
    



```python
# Histograms of the first ten features
sonar_data.iloc[:, :10].hist(bins=15, figsize=(15, 10))
plt.suptitle('Histograms of First 10 Features')
plt.show()
```


    
![png](output_13_0.png)
    



```python
# Pair plot of the first ten features
sns.pairplot(sonar_data.iloc[:, :10])
plt.suptitle('Pair Plots of First 10 Features', y=1.02)
plt.show()
```


    
![png](output_14_0.png)
    



```python
# Box plots to check for outliers
plt.figure(figsize=(15, 10))
for i in range(10):
    plt.subplot(2, 5, i+1)
    sns.boxplot(data=sonar_data, x=60, y=i)
    plt.title(f'Feature {i}')
plt.tight_layout()
plt.show()
```


    
![png](output_15_0.png)
    



```python
plt.figure(figsize=(6, 6))
sonar_data[60].value_counts().plot.pie(autopct='%1.1f%%', colors=['#66b3ff', '#99ff99'], labels=['Mines', 'Rocks'])
plt.title('Proportion of Target Variable')
plt.ylabel('')
plt.show()

```


    
![png](output_16_0.png)
    



```python
# Correlation heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(sonar_data.corr(), annot=False, cmap='coolwarm')
plt.title('Correlation Heatmap of Features')
plt.show()
```


    
![png](output_17_0.png)
    


# Training and Evaluating Logistic Regression Model


```python
# Training the Logistic Regression model
logistic_model = LogisticRegression(max_iter=1000)
logistic_model.fit(X_train, Y_train)
```




<style>#sk-container-id-3 {color: black;}#sk-container-id-3 pre{padding: 0;}#sk-container-id-3 div.sk-toggleable {background-color: white;}#sk-container-id-3 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-3 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-3 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-3 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-3 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-3 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-3 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-3 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-3 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-3 div.sk-item {position: relative;z-index: 1;}#sk-container-id-3 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-3 div.sk-item::before, #sk-container-id-3 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-3 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-3 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-3 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-3 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-3 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-3 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-3 div.sk-label-container {text-align: center;}#sk-container-id-3 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-3 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(max_iter=1000)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" checked><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(max_iter=1000)</pre></div></div></div></div></div>




```python
# Evaluating the Logistic Regression model
X_train_prediction = logistic_model.predict(X_train)
training_data_accuracy = accuracy_score(Y_train, X_train_prediction)
X_test_prediction = logistic_model.predict(X_test)
test_data_accuracy = accuracy_score(Y_test, X_test_prediction)
```


```python
print('Logistic Regression - Accuracy on training data:', training_data_accuracy)
print('Logistic Regression - Accuracy on test data:', test_data_accuracy)

```

    Logistic Regression - Accuracy on training data: 0.9197860962566845
    Logistic Regression - Accuracy on test data: 0.8095238095238095
    


```python
# Confusion matrix for the test data
cm = confusion_matrix(Y_test, X_test_prediction, labels=logistic_model.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=logistic_model.classes_)
disp.plot()
plt.title('Logistic Regression - Confusion Matrix')
plt.show()
```


    
![png](output_22_0.png)
    



```python
# ROC curve and AUC for Logistic Regression
y_prob = logistic_model.predict_proba(X_test)[:, 1]
fpr, tpr, _ = roc_curve(Y_test, y_prob)
roc_auc = roc_auc_score(Y_test, y_prob)
```


```python
plt.figure()
plt.plot(fpr, tpr, color='blue', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Logistic Regression - Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.show()
```


    
![png](output_24_0.png)
    



```python
input_data = (
    0.0307, 0.0523, 0.0653, 0.0521, 0.0611, 0.0577, 0.0665, 0.0664, 0.1460, 0.2792,
    0.3, 0.2301, 0.2456, 0.3423, 0.2123, 0.1122, 0.1345, 0.0763, 0.1654, 0.2876,
    0.3901, 0.3103, 0.2805, 0.1786, 0.1475, 0.0987, 0.1212, 0.2343, 0.2110, 0.1703,
    0.1189, 0.1992, 0.1407, 0.2344, 0.2754, 0.1982, 0.1655, 0.2453, 0.3122, 0.3901,
    0.3322, 0.2877, 0.2343, 0.1234, 0.1765, 0.2445, 0.2098, 0.1678, 0.2134, 0.2233,
    0.1987, 0.1567, 0.2231, 0.2645, 0.2411, 0.1798, 0.1564, 0.1233, 0.1321, 0.1010  
)

# Convert to numpy array
input_data_as_numpy_array = np.asarray(input_data)

# Reshape input for single prediction
input_data_reshaped = input_data_as_numpy_array.reshape(1, -1)

# Predict using trained logistic model
prediction = logistic_model.predict(input_data_reshaped)

# Print result
print("Prediction:", prediction)

if prediction[0] == 'R':
    print("The object is a Rock")
else:
    print("The object is a Mine")

```

    Prediction: [1]
    The object is a Mine
    


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
